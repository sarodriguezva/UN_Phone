# UN_Phone

Resource Pack para UN-Minecraft destinado a funcionalidades esenciales del juego como el telefono y sus respectivas aplicaciones, paquetes de texturas que permiten tener una mejor experiencia de roleplay e items añadidos según funcionalidad. 


Notas para los programadores :

- App Nequi no funciona botón volver al Menú inicial del celular ( <= ) no a la pagina anterior
- App Mercado libre Botón Inicio debe llevar al Menú del celular inicial, no a la anterior página
- Actualizar App Mercado Libre ( Esperar a que esté en Drive )
- Modificar Textos de App Nequi

- (Nota para Brayan) Actualizar GUI celular con la ultima del drive que contiene la app del trabajo , el archivo tiene el nombre de Plantilla_Celular2
